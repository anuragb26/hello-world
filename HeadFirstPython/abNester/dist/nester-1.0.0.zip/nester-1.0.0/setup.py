from distutils.core import setup

setup(
		name = 'nester',
		version = '1.0.0',
		py_modules = ['nester'],
		author  = 'anurag bajaj',
		author_email = 'anuragb26@gmail.com',
		description = 'Printer of nester lists',
		url = 'http://www.google.co.in'
     )
