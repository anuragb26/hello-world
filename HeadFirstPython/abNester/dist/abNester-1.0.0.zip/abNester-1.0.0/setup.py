from distutils.core import setup

setup(
		name = 'abNester',
		version = '1.0.0',
		py_modules = ['aaNester'],
		author  = 'anurag bajaj',
		author_email = 'anuragb26@gmail.com',
		description = 'Printer of nester lists',
		url = 'http://www.google.co.in'
     )
