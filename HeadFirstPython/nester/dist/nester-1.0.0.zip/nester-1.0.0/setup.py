from distutils.core import setup

setup(
		name = 'nester',
		version = '1.0.0',
		py_modules = ['nester'],
		author  = 'anurag bajaj',
		author_email = 'anuragb26@gmail.com',
		url = 'http://www.anuragb26.com',
		description = 'Printer of nester lists'
)